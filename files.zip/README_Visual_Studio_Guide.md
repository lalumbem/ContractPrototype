# TechMove Contract & Service Request Management System
Part 2: Core Prototype & Unit Testing. ASP.NET Core MVC (.NET 8), Entity Framework Core, SQL Server LocalDB, HttpClient currency API, xUnit.

## What is included
| Requirement | Where |
|---|---|
| Client / Contract / ServiceRequest models + EF Core SQL Server | `Models/`, `Data/AppDbContext.cs` |
| Status workflow: no requests for Expired / On Hold (or past end date) contracts | `Services/ContractService.cs` -> used in `ServiceRequestsController.Create` |
| LINQ search by date range + status | `ContractService.SearchAsync` -> `ContractsController.Index`, `Views/Contracts/Index.cshtml` |
| PDF signed agreement upload / download | `PdfValidator`, `FileStorageService`, `ContractsController` (Create, Edit, Download) |
| USD to ZAR live rate via HttpClient + auto-calculated ZAR cost | `CurrencyService`, `CurrencyCalculator`, `ServiceRequestsController.Create` |
| Full CRUD (Clients, Contracts, Service Requests) with safe delete rules | Controllers + Views |
| xUnit tests (currency, PDF validation, business rules, search, API handling) | `ContractPrototype.Tests/` |

Delete rules: a Client with contracts cannot be deleted; a Contract with service requests cannot be deleted; only Open/Cancelled service requests can be deleted.

---
## Guide: run it in Visual Studio (2022 17.8+ / 2026)
Prerequisites: Visual Studio with the **ASP.NET and web development** workload, the .NET 8 SDK, and SQL Server LocalDB (installed with that workload; check View > SQL Server Object Explorer).

### 1. Open and restore
1. Extract the zip. Double-click `ContractPrototypeSolution.sln`.
2. Wait for NuGet restore (or right-click solution > **Restore NuGet Packages**).
3. If you use a newer .NET (for example .NET 10), change `<TargetFramework>` in **both** `.csproj` files and update the EF Core package versions (`Microsoft.EntityFrameworkCore.*`, `...InMemory`) to the same major version.

### 2. Check the connection string
Open `ContractPrototype/appsettings.json`. The default uses LocalDB: `Server=(localdb)\MSSQLLocalDB;Database=ContractPrototypeDb;...`. For SQL Server Express use `Server=.\SQLEXPRESS;...`.

### 3. Create the migration (required for your submission)
1. **Tools > NuGet Package Manager > Package Manager Console**.
2. Set **Default project** to `ContractPrototype` and make sure it is the startup project.
3. Run:
   ```
   Add-Migration InitialCreate
   Update-Database
   ```
4. A `Migrations` folder appears in the project. Commit it (the assignment asks for the migration scripts).
5. Verify in **View > SQL Server Object Explorer > (localdb)\MSSQLLocalDB > Databases > ContractPrototypeDb > Tables** (Clients, Contracts, ServiceRequests).
6. Optional: generate a SQL script for the lecturer with `Script-Migration -Output migration.sql`.

### 4. Run the application
Press **Ctrl+F5**. In Development the app also applies migrations and seeds 2 clients and 4 contracts (Active, On Hold, Expired, Draft) so you can demo the rules immediately.

### 5. Demo / test script (take screenshots as you go)
1. **Clients**: add, edit, try deleting a client that has contracts (blocked).
2. **Contracts > Add contract**: choose a client, set dates, upload `docs/sample-agreement.pdf`. Then try uploading a `.txt` renamed to `.pdf` and an empty file: both are rejected. Click **Download** in the list to download the PDF.
3. **Search**: use the date range and status filter on the Contracts page. The URL contains the query string.
4. **Service requests**: create one for the Active contract in ZAR. Create one in **USD**: the page previews the converted amount, and the saved request shows the rate used. Try a request for the On Hold or Expired contract: it is rejected with a clear message.
5. Turn off Wi-Fi and submit a USD request to show the API error handling (no fake rate is used).

### 6. Run the unit tests
1. **Build > Build Solution**.
2. **Test > Test Explorer > Run All Tests**.
3. Screenshot Test Explorer showing every test green (required evidence).

Tests cover: currency conversion (R18.50 x $100 = R1,850.00, rounding, zero/negative rate), API handling (success, missing ZAR, HTTP 500, bad JSON) using a fake handler, PDF validation (valid, .exe, oversized, empty, fake PDF content), the contract workflow rule table, and the date/status search using the EF Core in-memory provider.

### 7. Push to GitHub
1. **Git > Create Git Repository** (bottom-right, or Git menu), choose GitHub, set the repo name and tick **Private** if required, then **Create and Push**.
2. Confirm `Migrations/` is included and no passwords are committed (`.gitignore` is provided).
3. Submit the repository link on ARC.

### 8. Video walkthrough (suggested outline, 5-8 minutes)
1. Solution structure (MVC app + test project) and the three models.
2. Show the database tables in SQL Server Object Explorer.
3. Demo CRUD, PDF upload/download, search and the blocked request for On Hold/Expired contracts.
4. Demo the USD to ZAR request, then explain `CurrencyService` + `CurrencyCalculator`.
5. Run Test Explorer and explain what each test group proves.

### 9. Optional: Azure deployment
Create Azure SQL + App Service, set the connection string in App Service **Configuration** (never in GitHub), right-click project > **Publish** > Azure App Service, and apply migrations (for example `Script-Migration` run against Azure SQL). Note: local `wwwroot/uploads` is not durable on App Service; use Azure Blob Storage for real deployments.

## Notes
- Currency API: `https://open.er-api.com/v6/latest/USD` (free, no key). Check its terms before production use. If it is unavailable, the app shows an error instead of guessing.
- Uploads are stored with generated GUID names; the original name is kept in the database for display. Downloads go through the controller, never a user-supplied path.
- Contract search matches contracts whose **start date** falls inside the chosen date range.
